package ph.cevfx.mtikmanager

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.view.View
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var host: EditText
    private lateinit var user: EditText
    private lateinit var pass: EditText
    private val worker = Executors.newSingleThreadExecutor()
    private var connected = false
    private var endpoint = ""
    private var login = ""
    private var password = ""
    private val navy = Color.rgb(18, 35, 61)
    private val blue = Color.rgb(28, 111, 216)

    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); connectionScreen() }
    private fun label(text: String, size: Float = 16f): TextView = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(navy); setPadding(8, 12, 8, 12)
    }
    private fun button(text: String, action: () -> Unit): Button = Button(this).apply { this.text = text; setOnClickListener { action() } }
    private fun field(hint: String, value: String = ""): EditText = EditText(this).apply {
        this.hint = hint; setText(value); setSingleLine(true); textSize = 16f
    }
    private fun start(title: String) {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 20, 20, 12); setBackgroundColor(Color.WHITE) }
        val heading = label(title, 23f).apply { setTextColor(blue) }
        root.addView(heading)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }
    private fun connectionScreen() {
        connected = false
        start("CEV-MTik-Manager  •  Android V1.0")
        content.addView(label("Standalone RouterOS v7 REST API  •  HTTPS only"))
        host = field("Router IP or hostname", endpoint.removePrefix("https://").substringBefore(":"))
        user = field("Router username", login)
        pass = field("Router password").apply { inputType = 129 }
        content.addView(host); content.addView(user); content.addView(pass)
        content.addView(label("Port: 443 (www-ssl). A valid, trusted HTTPS certificate is required. Credentials stay in memory only." , 13f))
        content.addView(button("Connect securely") {
            val h = host.text.toString().trim()
            if (h.isEmpty() || h.contains('/') || h.contains(':') || h.contains(' ')) { toast("Enter IP or hostname only"); return@button }
            endpoint = "https://$h:443"
            login = user.text.toString().trim(); password = pass.text.toString()
            if (login.isBlank() || password.isBlank()) { toast("Enter username and password"); return@button }
            request("system/identity") { data ->
                connected = true; dashboard()
            }
        })
    }
    private fun request(path: String, method: String = "GET", body: JSONObject? = null, callback: (JSONArray) -> Unit) {
        worker.execute {
            try {
                val conn = URL("$endpoint/rest/$path").openConnection() as HttpURLConnection
                conn.requestMethod = method; conn.connectTimeout = 8000; conn.readTimeout = 10000
                conn.setRequestProperty("Authorization", "Basic " + Base64.getEncoder().encodeToString("$login:$password".toByteArray(Charsets.UTF_8)))
                conn.setRequestProperty("Accept", "application/json")
                if (body != null) { conn.doOutput = true; conn.setRequestProperty("Content-Type", "application/json"); conn.outputStream.use { it.write(body.toString().toByteArray()) } }
                val status = conn.responseCode
                val response = (if (status in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                conn.disconnect()
                if (status !in 200..299) throw Exception("Router returned HTTP $status: ${response.take(160)}")
                val array = when { response.trim().startsWith("[") -> JSONArray(response); response.trim().startsWith("{") -> JSONArray().put(JSONObject(response)); else -> JSONArray() }
                runOnUiThread { callback(array) }
            } catch (e: Exception) { runOnUiThread { AlertDialog.Builder(this).setTitle("Connection / API error").setMessage(e.message ?: "Unknown error").setPositiveButton("OK", null).show() } }
        }
    }
    private fun nav() {
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("Home" to { dashboard() }, "Active" to { showList("Active PPPoE", "ppp/active") }, "Accounts" to { showList("PPPoE Accounts", "ppp/secret") }, "Profiles" to { showList("PPPoE Profiles", "ppp/profile") }).forEach { (name, action) ->
            bar.addView(button(name, action), LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(bar, 1)
    }
    private fun dashboard() {
        start("CEV-MTik-Manager")
        content.addView(label("Connected to $endpoint", 13f))
        content.addView(button("Disconnect") { endpoint = ""; login = ""; password = ""; connectionScreen() })
        content.addView(button("Refresh dashboard") { dashboard() })
        content.addView(label("Router resources", 20f))
        request("system/resource") { rows ->
            if (rows.length() > 0) { val j = rows.getJSONObject(0)
                content.addView(label("RouterOS: ${j.optString("version", "—")}\nCPU load: ${j.optString("cpu-load", "—")}%\nFree RAM: ${j.optString("free-memory", "—")} bytes\nUptime: ${j.optString("uptime", "—")}"))
            }
        }
        request("ppp/active") { rows -> content.addView(label("Online PPPoE clients: ${rows.length()}", 20f)) }
        request("ppp/secret") { rows -> content.addView(label("PPPoE accounts: ${rows.length()}", 20f)) }
        nav()
    }
    private fun showList(title: String, path: String) {
        start(title)
        content.addView(button("Refresh") { showList(title, path) })
        if (path == "ppp/secret") content.addView(button("Add PPPoE account") { addSecret() })
        content.addView(label("Loading…"))
        request(path) { rows ->
            content.removeViewAt(content.childCount - 1)
            content.addView(label("Total: ${rows.length()}", 14f))
            for (i in 0 until rows.length()) {
                val j = rows.getJSONObject(i)
                val name = j.optString("name", "(unnamed)")
                val summary = when (path) {
                    "ppp/active" -> "$name  •  ${j.optString("address", "")}  •  ${j.optString("uptime", "")}" 
                    "ppp/secret" -> "$name  •  ${j.optString("profile", "default")}  •  ${if (j.optString("disabled") == "true") "Disabled" else "Enabled"}"
                    else -> "$name  •  ${j.optString("rate-limit", "No rate limit")}" }
                content.addView(button(summary) { if (path == "ppp/secret") secretActions(j) else AlertDialog.Builder(this).setTitle(name).setMessage(j.toString(2)).setPositiveButton("OK", null).show() })
            }
        }
        nav()
    }
    private fun secretActions(j: JSONObject) {
        val id = j.optString(".id")
        val disabled = j.optString("disabled") == "true"
        if (id.isBlank()) { toast("Missing account ID"); return }
        val action = if (disabled) "Enable" else "Disable"
        AlertDialog.Builder(this).setTitle(j.optString("name"))
            .setMessage("$action this PPPoE account?")
            .setNegativeButton("Cancel", null)
            .setPositiveButton(action) { _, _ ->
                request("ppp/secret/${encodeId(id)}", "PATCH", JSONObject().put("disabled", if (disabled) "false" else "true")) { showList("PPPoE Accounts", "ppp/secret") }
            }.show()
    }
    private fun encodeId(id: String): String = java.net.URLEncoder.encode(id, "UTF-8").replace("+", "%20")
    private fun addSecret() {
        val form = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 0, 20, 0) }
        val name = field("PPPoE username"); val pw = field("PPPoE password"); val profile = field("Profile", "default")
        form.addView(name); form.addView(pw); form.addView(profile)
        AlertDialog.Builder(this).setTitle("New PPPoE account").setView(form)
            .setNegativeButton("Cancel", null).setPositiveButton("Create") { _, _ ->
                if (name.text.isBlank() || pw.text.isBlank()) { toast("Username/password required"); return@setPositiveButton }
                val obj = JSONObject().put("name", name.text.toString()).put("password", pw.text.toString()).put("profile", profile.text.toString()).put("service", "pppoe")
                request("ppp/secret", "PUT", obj) { showList("PPPoE Accounts", "ppp/secret") }
            }.show()
    }
    private fun toast(message: String) { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    override fun onDestroy() { worker.shutdownNow(); super.onDestroy() }
}
