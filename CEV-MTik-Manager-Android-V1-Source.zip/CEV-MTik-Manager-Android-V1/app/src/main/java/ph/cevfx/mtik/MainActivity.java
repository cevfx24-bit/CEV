package ph.cevfx.mtik;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import org.json.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    EditText host, user, pass;
    TextView result;
    final java.util.concurrent.ExecutorService pool = Executors.newSingleThreadExecutor();
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout root = new LinearLayout(this); root.setOrientation(1); root.setPadding(28,28,28,28); root.setBackgroundColor(Color.rgb(245,248,252));
        ScrollView scroll = new ScrollView(this); scroll.addView(root); setContentView(scroll);
        TextView title = new TextView(this); title.setText("CEV-MTik-Manager\nAndroid V1.0 • Standalone"); title.setTextSize(24); title.setTextColor(Color.rgb(15,40,75)); root.addView(title);
        host = field(root,"Router address (e.g. 192.168.88.1:443)","192.168.88.1:443",false);
        user = field(root,"MikroTik API username","",false);
        pass = field(root,"MikroTik API password","",true);
        Button connect = button(root,"Connect / Router Overview",()->load("system/resource","overview"));
        button(root,"Active PPPoE Sessions",()->load("ppp/active","sessions"));
        button(root,"PPPoE Accounts",()->load("ppp/secret","accounts"));
        button(root,"PPPoE Profiles",()->load("ppp/profile","profiles"));
        result = new TextView(this); result.setText("Enter MikroTik credentials. HTTPS only; the router certificate must be trusted by Android.\n\nNo credentials are stored by this development build."); result.setTextSize(15); result.setTextColor(Color.rgb(24,39,58)); result.setPadding(0,24,0,24); root.addView(result);
    }
    EditText field(LinearLayout parent,String hint,String value,boolean secret) {
        EditText e=new EditText(this); e.setHint(hint); e.setSingleLine(true); e.setText(value);
        if(secret) e.setInputType(129);
        parent.addView(e,new LinearLayout.LayoutParams(-1,-2)); return e;
    }
    Button button(LinearLayout parent,String label,Runnable click) {
        Button b=new Button(this); b.setText(label); parent.addView(b); b.setOnClickListener(v->click.run()); return b;
    }
    void load(String path,String kind) {
        final String address=host.getText().toString().trim();
        final String username=user.getText().toString();
        final String password=pass.getText().toString();
        if(address.isEmpty() || username.isEmpty()) { result.setText("Enter router address and username."); return; }
        if(address.contains("/") || address.contains("@") || address.contains("?") || address.contains("#")) {result.setText("Use only router hostname/IP and optional port."); return;}
        result.setText("Connecting securely...");
        pool.execute(()->{
            try {
                URL url=new URL("https://"+address+"/rest/"+path);
                if(!url.getProtocol().equals("https")) throw new IOException("HTTPS required");
                HttpURLConnection conn=(HttpURLConnection)url.openConnection();
                conn.setConnectTimeout(7000); conn.setReadTimeout(10000);
                conn.setRequestProperty("Authorization","Basic "+Base64.getEncoder().encodeToString((username+":"+password).getBytes(StandardCharsets.UTF_8)));
                conn.setRequestProperty("Accept","application/json");
                conn.setInstanceFollowRedirects(false);
                int status=conn.getResponseCode();
                if(status!=200) throw new IOException("Router returned HTTP "+status+". Check REST access, credentials and permissions.");
                ByteArrayOutputStream out=new ByteArrayOutputStream();
                try(InputStream in=conn.getInputStream()) { byte[] buffer=new byte[4096]; int n; while((n=in.read(buffer))!=-1) { if(out.size()+n>1024*1024) throw new IOException("Response too large"); out.write(buffer,0,n); } }
                String raw=out.toString("UTF-8");
                String display=format(raw,kind);
                runOnUiThread(()->result.setText(display));
                conn.disconnect();
            } catch(Exception e) {runOnUiThread(()->result.setText("Connection failed: "+e.getMessage()+"\n\nCheck that www-ssl is enabled, the certificate is trusted, and your phone can reach the router."));}
        });
    }
    String format(String raw,String kind) throws JSONException {
        StringBuilder sb=new StringBuilder();
        if(kind.equals("overview")) {
            JSONArray a=new JSONArray(raw); if(a.length()==0) return "No resource data";
            JSONObject o=a.getJSONObject(0);
            for(String key:new String[]{"version","board-name","cpu","cpu-count","cpu-load","free-memory","total-memory","uptime"}) sb.append(key).append(": ").append(o.optString(key,"—")).append("\n");
        } else {
            JSONArray a=new JSONArray(raw); sb.append(kind.toUpperCase()).append(" • ").append(a.length()).append(" records\n\n");
            for(int i=0;i<Math.min(a.length(),150);i++) {
                JSONObject o=a.getJSONObject(i);
                sb.append(i+1).append(". ").append(o.optString("name","(unnamed)"));
                if(o.has("profile")) sb.append(" | ").append(o.optString("profile"));
                if(o.has("address")) sb.append(" | ").append(o.optString("address"));
                if(o.has("uptime")) sb.append(" | ").append(o.optString("uptime"));
                if(o.has("disabled")) sb.append(" | disabled: ").append(o.optString("disabled"));
                sb.append("\n");
            }
            if(a.length()>150) sb.append("\nShowing first 150 records.");
        }
        return sb.toString();
    }
    @Override protected void onDestroy(){pool.shutdownNow();super.onDestroy();}
}
