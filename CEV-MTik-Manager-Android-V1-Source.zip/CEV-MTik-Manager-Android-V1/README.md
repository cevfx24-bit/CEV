# CEV-MTik-Manager Android V1.0 — standalone prototype

Native Kotlin Android Studio project, based on the MikroTik feature inventory of CEV-MTik-Manager V9.8.5.19. **Not an APK binary yet.**

## Features implemented
- Direct HTTPS REST connection to RouterOS v7 (port 443)
- Dashboard with router CPU, free memory, uptime, RouterOS version, online PPPoE count and secret count
- Active PPPoE sessions, PPPoE secrets, PPPoE profiles
- Create PPPoE secret and enable/disable with confirmation
- No Flask/Windows PC required; credentials only held in app memory

## Build
1. Open this folder in Android Studio (JDK 17, Android SDK 35).
2. Wait for Gradle sync and install missing SDK packages if prompted.
3. Build > Build APK(s); output: `app/build/outputs/apk/debug/app-debug.apk`.
4. Install on Android 8.0 or later.

## MikroTik setup
Enable `www-ssl` and configure a certificate trusted by the Android device. Use a dedicated RouterOS account with only necessary permissions. Use a VPN to access routers remotely rather than opening the management port to the public internet. Test with a spare router or test account before making changes. Do not disable TLS verification.

## Scope and caveats
This is an initial native port, not feature parity with the Windows V9.8.5.19 application. Billing, scheduling, licensing, local database, certificate generation, hotspot/voucher, graphs and printing are not ported. No APK was compiled or tested against a real router in this environment. The original hybrid license implementation is not copied into Android. No private license signing keys are included.
